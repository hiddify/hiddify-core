package hcore

import (
	"context"
	"fmt"
	"net"
	"runtime"
	"strings"
	"time"

	"github.com/hiddify/hiddify-core/v2/config"
	"github.com/hiddify/hiddify-core/v2/db"
	hcommon "github.com/hiddify/hiddify-core/v2/hcommon"
	"github.com/sagernet/sing-box/adapter"
	"github.com/wlynxg/anet"

	// "github.com/sagernet/sing-box/common/conntrack"
	"github.com/sagernet/sing-box/protocol/group"

	"github.com/sagernet/sing-box/common/monitoring"
	E "github.com/sagernet/sing/common/exceptions"
	"github.com/sagernet/sing/common/memory"
	"google.golang.org/grpc"
)

func (h *HiddifyInstance) readStatus(prev *SystemInfo) *SystemInfo {
	var message SystemInfo
	message.Memory = int64(memory.Inuse())
	message.Goroutines = int32(runtime.NumGoroutine())
	// message.ConnectionsOut = int32(conntrack.Count())

	if ss := h.StartedService; ss != nil {
		status := ss.ReadStatus()
		message.DownlinkTotal = status.DownlinkTotal
		message.UplinkTotal = status.UplinkTotal
		message.ConnectionsIn = status.ConnectionsIn
		message.ConnectionsOut = status.ConnectionsOut

		if prev != nil {
			message.Uplink = message.UplinkTotal - prev.UplinkTotal
			message.Downlink = message.DownlinkTotal - prev.DownlinkTotal
		}
		if box := h.Box(); box != nil {
			current := ""
			if currentOutBound, ok := box.Outbound().Outbound(config.OutboundSelectTag); ok {
				if selectOutBound, ok := currentOutBound.(*group.Selector); ok {
					current = groupNow(selectOutBound)
					message.CurrentOutbound = TrimTagName(current)
				}
			}
			// if message.CurrentOutbound == config.OutboundURLTestTag {
			if currentOutBound, ok := box.Outbound().Outbound(current); ok {
				if g, ok := currentOutBound.(adapter.OutboundGroup); ok {
					if now := groupNow(g); now != "" {
						message.CurrentOutbound = fmt.Sprint(message.CurrentOutbound, "→", TrimTagName(now))
					}
				}
			}
			// }
		}

		if prev == nil || prev.CurrentProfile == "" || message.UplinkTotal < 1000000 {
			settings := db.GetTable[hcommon.AppSettings]()
			lastName, err := settings.Get("lastStartRequestName")
			if err == nil {
				message.CurrentProfile = lastName.Value.(string)
			}
		} else {
			message.CurrentProfile = prev.CurrentProfile
		}
	}

	return &message
}

func (s *CoreService) GetSystemInfo(ctx context.Context, req *hcommon.Empty) (*SystemInfo, error) {
	return static.readStatus(nil), nil

}
func (s *CoreService) GetSystemInfoStream(req *hcommon.Empty, stream grpc.ServerStreamingServer[SystemInfo]) error {
	return static.GetSystemInfo(stream)

}
func (h *HiddifyInstance) MakeSureContextIsNew(streamContext context.Context) {
	for range 10 {
		if ctx := h.Context(); ctx != nil {
			select {
			case <-ctx.Done(): //if old context is done waiting for new context
			default:
				return
			}
		}
		select {
		case <-streamContext.Done():
			return
		case <-time.After(time.Millisecond * 500):
		}
	}
}
func (h *HiddifyInstance) GetSystemInfo(stream grpc.ServerStreamingServer[SystemInfo]) error {
	// return fmt.Errorf("not implemented yet")
	h.MakeSureContextIsNew(stream.Context())

	ticker := time.NewTicker(1 * time.Second)
	defer ticker.Stop()

	deadline := time.NewTimer(10 * time.Second)
	defer deadline.Stop()

	ctx := h.Context()
	if ctx == nil {
		return E.New("service not ready")
	}
	current_status := h.readStatus(nil)
	if err := stream.Send(current_status); err != nil {
		Log(LogLevel_ERROR, LogType_CORE, "send System Info failed", err)
	}
	for {
		select {
		case <-stream.Context().Done():
			return nil
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
			current_status = h.readStatus(current_status)
			if err := stream.Send(current_status); err != nil {
				// return err
				Log(LogLevel_ERROR, LogType_CORE, "send System Info failed", err)
			}
		}
	}

}

// func (s *CoreService) OutboundsInfo(req *hcommon.Empty, stream grpc.ServerStreamingServer[OutboundGroupList]) error {
// 	if groupClient == nil {
// 		groupClient = libbox.NewCommandClient(
// 			&CommandClientHandler{
// 				command: libbox.CommandGroup,
// 				// port:   s.port,
// 			},
// 			&libbox.CommandClientOptions{
// 				Command:        libbox.CommandGroup,
// 				StatusInterval: 500000000, // 500ms debounce
// 			},
// 		)

// 		defer func() {
// 			groupClient.Disconnect()
// 			groupClient = nil
// 		}()

// 		groupClient.Connect()
// 	}

// 	sub, done, _ := outboundsInfoObserver.Subscribe()

// 	for {
// 		select {
// 		case <-stream.Context().Done():
// 			return nil
// 		case <-done:
// 			return nil
// 		case info := <-sub:
// 			stream.Send(info)
// 			// case <-time.After(500 * time.Millisecond):
// 		}
// 	}
// }

// func (s *CoreService) MainOutboundsInfo(req *hcommon.Empty, stream grpc.ServerStreamingServer[OutboundGroupList]) error {
// 	if groupInfoOnlyClient == nil {
// 		groupInfoOnlyClient = libbox.NewCommandClient(
// 			&CommandClientHandler{
// 				command: libbox.CommandGroupInfoOnly,
// 				// port:   s.port,
// 			},
// 			&libbox.CommandClientOptions{
// 				Command:        libbox.CommandGroupInfoOnly,
// 				StatusInterval: 500000000, // 500ms debounce
// 			},
// 		)

// 		defer func() {
// 			groupInfoOnlyClient.Disconnect()
// 			groupInfoOnlyClient = nil
// 		}()
// 		groupInfoOnlyClient.Connect()
// 	}

// 	sub, stopch, _ := mainOutboundsInfoObserver.Subscribe()

// 	for {
// 		select {
// 		case <-stream.Context().Done():
// 			return nil
// 		case <-stopch:
// 			return nil
// 		case info := <-sub:
// 			stream.Send(info)
// 			// case <-time.After(500 * time.Millisecond):
// 		}
// 	}
// }

func (s *CoreService) SelectOutbound(ctx context.Context, in *SelectOutboundRequest) (*hcommon.Response, error) {
	return static.SelectOutbound(in)
}

func (h *HiddifyInstance) SelectOutbound(in *SelectOutboundRequest) (*hcommon.Response, error) {
	// err := libbox.NewStandaloneCommandClient().SelectOutbound(in.GroupTag, in.OutboundTag)
	// if err != nil {
	// 	return &hcommon.Response{
	// 		Code:    hcommon.ResponseCode_FAILED,
	// 		Message: err.Error(),
	// 	}, err
	// }

	// return &hcommon.Response{
	// 	Code:    hcommon.ResponseCode_OK,
	// 	Message: "",
	// }, nil
	Log(LogLevel_DEBUG, LogType_CORE, "select outbound: ", in.GroupTag, " -> ", in.OutboundTag)
	if box := h.Box(); box != nil {
		outboundGroup, isLoaded := box.Outbound().Outbound(in.GroupTag)
		if !isLoaded {
			return &hcommon.Response{
				Code:    hcommon.ResponseCode_FAILED,
				Message: E.New("selector not found: ", in.GroupTag).Error(),
			}, E.New("selector not found: ", in.GroupTag)
		}
		selector, isSelector := outboundGroup.(*group.Selector)
		if !isSelector {
			return &hcommon.Response{
				Code:    hcommon.ResponseCode_FAILED,
				Message: E.New("outbound is not a selector: ", in.GroupTag).Error(),
			}, E.New("outbound is not a selector: ", in.GroupTag)
		}
		if !selector.SelectOutbound(in.OutboundTag) {
			return &hcommon.Response{
				Code:    hcommon.ResponseCode_FAILED,
				Message: E.New("outbound not found in selector:: ", in.GroupTag).Error(),
			}, E.New("outbound not found in selector: ", in.GroupTag)
		}
	} else {
		err := E.New("service not started")
		return &hcommon.Response{Code: hcommon.ResponseCode_FAILED, Message: err.Error()}, err
	}
	return &hcommon.Response{
		Code:    hcommon.ResponseCode_OK,
		Message: "",
	}, nil
}

func (s *CoreService) UrlTest(ctx context.Context, in *UrlTestRequest) (*hcommon.Response, error) {
	return static.UrlTest(in)
}

func (s *CoreService) UrlTestActive(ctx context.Context, in *hcommon.Empty) (*hcommon.Response, error) {

	return static.UrlTestActive()
}

func (h *HiddifyInstance) UrlTestActive() (*hcommon.Response, error) {
	if box := h.Box(); box != nil {
		outboundGroup, isLoaded := box.Outbound().Outbound(config.OutboundSelectTag)
		if !isLoaded {
			return &hcommon.Response{
				Code:    hcommon.ResponseCode_FAILED,
				Message: E.New("selector not found: ", config.OutboundSelectTag).Error(),
			}, E.New("selector not found: ", config.OutboundSelectTag)
		}
		selector, isSelector := outboundGroup.(adapter.OutboundGroup)
		if !isSelector {
			return &hcommon.Response{
				Code:    hcommon.ResponseCode_FAILED,
				Message: E.New("outbound is not a selector: ", config.OutboundSelectTag).Error(),
			}, E.New("outbound is not a selector: ", config.OutboundSelectTag)
		}
		now := groupNow(selector)
		if now == "" {
			return &hcommon.Response{
				Code:    hcommon.ResponseCode_FAILED,
				Message: E.New("outbound not found in selector: ", config.OutboundSelectTag).Error(),
			}, E.New("outbound not found in selector: ", config.OutboundSelectTag)
		}
		if outboundGroupInner, isLoaded := box.Outbound().Outbound(now); isLoaded {
			if grp, isgrp := outboundGroupInner.(adapter.OutboundGroup); isgrp {
				if n2 := groupNow(grp); n2 != "" {
					now = n2
				}
			}

		}
		return h.UrlTest(&UrlTestRequest{
			Tag: now,
		})

	}
	return &hcommon.Response{
		Code:    hcommon.ResponseCode_OK,
		Message: "",
	}, nil
}

func (h *HiddifyInstance) UrlTest(in *UrlTestRequest) (*hcommon.Response, error) {
	if in.Tag == "" {
		return h.UrlTestActive()
	}
	// err := libbox.NewStandaloneCommandClient().URLTest(in.GroupTag)
	// if err != nil {
	// 	return &hcommon.Response{
	// 		Code:    hcommon.ResponseCode_FAILED,
	// 		Message: err.Error(),
	// 	}, err
	// }

	// return &hcommon.Response{
	// 	Code:    hcommon.ResponseCode_OK,
	// 	Message: "",
	// }, nil

	// groupTag := in.GroupTag
	box := h.Box()
	if box == nil {
		return nil, E.New("service not ready")
	}
	monitor := monitoring.Get(h.Context())
	monitor.TestNow(in.Tag)
	// router := box.Outbound()
	// abstractOutboundGroup, isLoaded := router.Outbound(groupTag)
	// if !isLoaded {
	// 	return &hcommon.Response{
	// 		Code:    hcommon.ResponseCode_FAILED,
	// 		Message: E.New("outbound group not found: ", in.GroupTag).Error(),
	// 	}, E.New("outbound group not found: ", groupTag)
	// }
	// outboundGroup, isOutboundGroup := abstractOutboundGroup.(adapter.OutboundGroup)
	// if !isOutboundGroup {
	// 	return &hcommon.Response{
	// 		Code:    hcommon.ResponseCode_FAILED,
	// 		Message: E.New("outbound is not a group: ", in.GroupTag).Error(),
	// 	}, E.New("outbound is not a group: ", groupTag)
	// }

	// if urlTest, isURLTest := abstractOutboundGroup.(*group.URLTest); isURLTest {
	// 	go func() {
	// 		for _, p := range router.Outbounds() {
	// 			if p.Tag() == groupTag {
	// 				continue
	// 			}
	// 			if group, isGroup := p.(adapter.OutboundGroup); isGroup {
	// 				urlTest.ForceRecheckOutbound(group.Now())
	// 			}
	// 		}
	// 		urlTest.CheckOutbounds()
	// 	}()
	// } else {
	// 	historyStorage := h.UrlTestHistory()
	// 	outbounds := common.Filter(common.Map(outboundGroup.All(), func(it string) adapter.Outbound {
	// 		itOutbound, _ := router.Outbound(it)
	// 		return itOutbound
	// 	}), func(it adapter.Outbound) bool {
	// 		if it == nil {
	// 			return false
	// 		}
	// 		_, isGroup := it.(adapter.OutboundGroup)
	// 		return !isGroup
	// 	})
	// 	b, _ := batch.New(h.Context(), batch.WithConcurrencyNum[any](10))
	// 	for _, detour := range outbounds {
	// 		outboundToTest := detour
	// 		outboundTag := outboundToTest.Tag()
	// 		b.Go(outboundTag, func() (any, error) {
	// 			instance := box

	// 			group.CheckOutbound(instance.Logger(), h.Context(), historyStorage, router, "", outboundToTest, nil)
	// 			return nil, nil
	// 		})
	// 	}
	// }

	return &hcommon.Response{
		Code:    hcommon.ResponseCode_OK,
		Message: "",
	}, nil
}

func (s *CoreService) GetLANIP(ctx context.Context, req *hcommon.Empty) (*LANIPResponse, error) {
	// Use anet instead of net to bypass Android 11+ SELinux restrictions
	// that block direct Netlink socket binding (permission denied error).
	ifaces, err := anet.Interfaces()
	if err != nil {
		Log(LogLevel_ERROR, LogType_CORE, "GetLANIP failed: ", err)
		return &LANIPResponse{Ip: "127.0.0.1"}, nil
	}

	for _, iface := range ifaces {
		// Filter out interfaces that are down, loopback, or point-to-point (VPN/Tunnels)
		if iface.Flags&net.FlagUp == 0 || iface.Flags&net.FlagLoopback != 0 || iface.Flags&net.FlagPointToPoint != 0 {
			continue
		}

		// Exclude interfaces with names typical for VPNs, TAP, or TUN devices
		name := strings.ToLower(iface.Name)
		if strings.Contains(name, "tun") || strings.Contains(name, "tap") ||
			strings.Contains(name, "wintun") || strings.Contains(name, "utun") ||
			strings.Contains(name, "vpn") || strings.Contains(name, "ppp") {
			continue
		}

		// Retrieve addresses using anet to ensure compatibility on Android 11+
		addrs, err := anet.InterfaceAddrsByInterface(&iface)
		if err != nil {
			continue
		}

		for _, addr := range addrs {
			var ip net.IP
			switch v := addr.(type) {
			case *net.IPNet:
				ip = v.IP
			case *net.IPAddr:
				ip = v.IP
			}

			if ip == nil || ip.IsLoopback() {
				continue
			}

			// Ensure it is a valid IPv4 address
			ip4 := ip.To4()
			if ip4 == nil {
				continue
			}

			// Verify the IP belongs to a standard private IP range (RFC 1918)
			if ip4[0] == 10 ||
				(ip4[0] == 172 && ip4[1] >= 16 && ip4[1] <= 31) ||
				(ip4[0] == 192 && ip4[1] == 168) {
				return &LANIPResponse{Ip: ip4.String()}, nil
			}
		}
	}
	// Fallback to loopback if no physical LAN interface is found
	return &LANIPResponse{Ip: "127.0.0.1"}, nil
}
