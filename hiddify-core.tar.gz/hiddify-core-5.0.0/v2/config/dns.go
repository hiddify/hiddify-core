package config

import (
	"fmt"
	"net/netip"
	"net/url"
	"slices"
	"sort"
	"strconv"
	"strings"
	"time"

	// dnscode "github.com/miekg/dns"
	C "github.com/sagernet/sing-box/constant"
	"github.com/sagernet/sing-box/option"
	E "github.com/sagernet/sing/common/exceptions"
	"github.com/sagernet/sing/common/json/badjson"
	"github.com/sagernet/sing/common/json/badoption"
	M "github.com/sagernet/sing/common/metadata"
)

var DnsDirectTags = []string{
	DNSStaticTag,
	DNSDirectTag,
	DNSLocalTag,
}
var DnsRemoteTags = []string{
	DNSRemoteTag,
	DNSRemoteTagFallback,
	DNSTricksDirectTag,
}

var DEFAULT_DNS_TTL = uint32(60 * 60 * 24)

func getDnsAddress(d string) string {
	if !strings.Contains(d, "://") {
		return "udp://" + d
	}
	return d
}

func setDns(options *option.Options, opt *HiddifyOptions, staticIps *map[string][]string) error {
	remoteAddr := getDnsAddress(opt.RemoteDnsAddress)
	fallbackAddr := "https://8.8.8.8/dns-query"
	if remoteAddr == fallbackAddr {
		fallbackAddr = "https://1.0.0.1/dns-query"
	}

	// if strings.HasPrefix(remoteAddr, "udp://") {
	// 	remoteAddr = strings.Replace(remoteAddr, "udp://", "tcp://", 1)
	// }

	remote_dns, err := getDNSServerOptions(DNSRemoteTag, remoteAddr, DNSDirectTag, OutboundMainDetour)
	if err != nil {
		return err
	}
	remote_dns_fallback, err := getDNSServerOptions(DNSRemoteTagFallback, fallbackAddr, DNSDirectTag, OutboundMainDetour)
	if err != nil {
		return err
	}
	remote_no_warp_dns, err := getDNSServerOptions(DNSRemoteNoWarpTag, opt.RemoteDnsAddress, DNSDirectTag, OutboundWARPConfigDetour)
	if err != nil {
		return err
	}

	direct_detour := OutboundDirectFragmentTag
	if strings.HasPrefix(opt.DirectDnsAddress, "udp://") || !strings.Contains(opt.DirectDnsAddress, "://") {
		direct_detour = ""
	}

	direct_dns, err := getDNSServerOptions(DNSDirectTag, opt.DirectDnsAddress, DNSLocalTag, direct_detour)
	if err != nil {
		return err
	}
	trick_dns, err := getDNSServerOptions(DNSTricksDirectTag, "https://dns.cloudflare.com/dns-query#fragment=300", DNSDirectTag, OutboundDirectFragmentTag)
	if err != nil {
		return err
	}
	local_dns, err := getDNSServerOptions(DNSLocalTag, "local", "", "")
	if err != nil {
		return err
	}
	static_dns, err := getStaticDNSServerOptions(DNSStaticTag, staticIps)
	if err != nil {
		return err
	}
	remoteGroup, remoteMembers, err := getDNSGroupOptions(DNSMultiRemoteTag, *remote_dns, remoteAddr, DNSDirectTag, func(string) string {
		return OutboundMainDetour
	})
	if err != nil {
		return err
	}
	directGroup, directMembers, err := getDNSGroupOptions(DNSMultiDirectTag, *direct_dns, opt.DirectDnsAddress, DNSLocalTag, func(address string) string {
		if strings.HasPrefix(address, "udp://") {
			return ""
		}
		return OutboundDirectFragmentTag
	})
	if err != nil {
		return err
	}
	// block_dns, err := getDNSServerOptions(DNSBlockTag, "rcode://name_error", "", "")
	// if err != nil {
	// 	return err
	// }

	// multi_dns_direct, err := getMultiDnsServerOptions(DNSMultiDirectTag, DnsDirectTags, false)
	// if err != nil {
	// 	return err
	// }

	// multi_dns_remote, err := getMultiDnsServerOptions(DNSMultiRemoteTag, DnsRemoteTags, true)
	// if err != nil {
	// 	return err
	// }

	dnsOptions := option.DNSOptions{
		RawDNSOptions: option.RawDNSOptions{
			DNSClientOptions: option.DNSClientOptions{
				IndependentCache: opt.IndependentDNSCache && !C.IsIos,
				DisableExpire:    true,
			},
			Final: DNSMultiRemoteTag,

			Servers: []option.DNSServerOptions{
				*static_dns,
				*remote_dns,
				*remote_dns_fallback,
				*trick_dns,
				*direct_dns,
				*local_dns,
				*remote_no_warp_dns,
				*remoteGroup,
				*directGroup,
				// *multi_dns_direct,
				// *multi_dns_remote,
				// *block_dns,
			},
			Rules: []option.DNSRule{},
		},
	}
	if opt.EnableFakeDNS {
		inet4Range := badoption.Prefix(netip.MustParsePrefix("198.18.0.0/15"))
		inet6Range := badoption.Prefix(netip.MustParsePrefix("fc00::/18"))
		dnsOptions.Servers = append(dnsOptions.Servers, option.DNSServerOptions{
			Tag:  DNSFakeTag,
			Type: C.DNSTypeFakeIP,
			Options: &option.FakeIPDNSServerOptions{
				Inet4Range: &inet4Range,
				Inet6Range: &inet6Range,
			},
		})
	}
	dnsOptions.Servers = append(dnsOptions.Servers, remoteMembers...)
	dnsOptions.Servers = append(dnsOptions.Servers, directMembers...)
	options.DNS = &dnsOptions

	// options.DNS.StaticIPs["time.apple.com"] = []string{"time.g.aaplimg.com", "time.apple.com"}
	// options.DNS.StaticIPs["ipinfo.io"] = []string{"ipinfo.io"}
	// options.DNS.StaticIPs["dns.cloudflare.com"] = []string{"www.speedtest.net", "cloudflare.com"}
	// options.DNS.StaticIPs["ipwho.is"] = []string{"ipwho.is"}
	// options.DNS.StaticIPs["api.my-ip.io"] = []string{"api.my-ip.io"}
	// options.DNS.StaticIPs["myip.expert"] = []string{"myip.expert"}
	// options.DNS.StaticIPs["ip-api.com"] = []string{"ip-api.com"}
	// options.DNS.StaticIPs["freeipapi.com"] = []string{"www.speedtest.net", "cloudflare.com"}
	// options.DNS.StaticIPs["reallyfreegeoip.org"] = []string{"www.speedtest.net", "cloudflare.com"}
	// options.DNS.StaticIPs["ipapi.co"] = []string{"www.speedtest.net", "cloudflare.com"}
	// options.DNS.StaticIPs["api.ip.sb"] = []string{"www.speedtest.net", "cloudflare.com"}
	return nil
}
func getAllOutboundsOptions(options *option.Options) []any {
	outbounds := []any{}
	for _, o := range options.Outbounds {
		outbounds = append(outbounds, o.Options)
	}
	for _, o := range options.Endpoints {
		outbounds = append(outbounds, o.Options)
	}
	return outbounds
}
func addForceDirect(options *option.Options, hopt *HiddifyOptions) ([]option.DefaultDNSRule, error) {
	dnsMap := make(map[string]string)
	// outbounds := getAllOutboundsOptions(options)

	// for _, outbound := range outbounds {
	// 	// fmt.Println("out", outbound)
	// 	if server, ok := outbound.(option.ServerOptionsWrapper); ok {
	// 		serverDomain := server.TakeServerOptions().Server
	// 		detour := OutboundDirectTag
	// 		if dialer, ok := outbound.(option.DialerOptionsWrapper); ok {
	// 			if server_detour := dialer.TakeDialerOptions().Detour; server_detour != "" {
	// 				detour = server_detour
	// 			}
	// 		}
	// 		fmt.Println("serverDomain", serverDomain, "detour", detour)

	// 		if host, err := getHostnameIfNotIP(serverDomain); err == nil && host != "" {
	// 			fmt.Println("serverDomain", serverDomain, "host", host, "detour", detour)
	// 			if _, ok := dnsMap[host]; !ok || detour == OutboundDirectTag {
	// 				dnsMap[host] = detour
	// 			}
	// 		}
	// 	}
	// }

	// // dnsMap[]
	forceDirectRules := []option.DefaultDNSRule{}
	// if len(dnsMap) > 0 {
	// 	unique_dns_detours := make(map[string]bool)
	// 	for _, detour := range dnsMap {
	// 		unique_dns_detours[detour] = true
	// 	}

	// 	for detour := range unique_dns_detours {
	// 		domains := []string{}
	// 		for domain, d := range dnsMap {
	// 			if d == detour {
	// 				domains = append(domains, domain)
	// 			}
	// 		}
	// 		if len(domains) == 0 {
	// 			continue
	// 		}
	// 		dns_detour := DNSMultiDirectTag
	// 		if detour != OutboundDirectTag {
	// 			dns_detour = "dns-" + detour
	// 			remote_dns, err := getDNSServerOptions(dns_detour, hopt.RemoteDnsAddress, DNSDirectTag, detour)
	// 			if err != nil {
	// 				return nil, err
	// 			}
	// 			options.DNS.Servers = append(options.DNS.Servers, *remote_dns)

	// 		}

	// 		forceDirectRules = append(forceDirectRules,
	// 			option.DefaultDNSRule{
	// 				RawDefaultDNSRule: option.RawDefaultDNSRule{
	// 					Domain: domains,
	// 				},
	// 				DNSRuleAction: option.DNSRuleAction{
	// 					Action: C.RuleActionTypeRoute,
	// 					RouteOptions: option.DNSRouteActionOptions{
	// 						Server:         dns_detour,
	// 						BypassIfFailed: false,
	// 					},
	// 				},
	// 			},
	// 		)
	// 	}
	// }

	forceDirectRules = append(forceDirectRules,
		option.DefaultDNSRule{
			RawDefaultDNSRule: option.RawDefaultDNSRule{
				Domain: []string{"api.cloudflareclient.com"},
			},
			DNSRuleAction: option.DNSRuleAction{
				Action: C.RuleActionTypeRoute,
				RouteOptions: option.DNSRouteActionOptions{
					Server: DNSRemoteNoWarpTag,
					AbstractDNSRouteActionOptions: option.AbstractDNSRouteActionOptions{
						Strategy:       hopt.DirectDnsDomainStrategy,
						BypassIfFailed: false,
						RewriteTTL:     &DEFAULT_DNS_TTL,
					},
				},
			},
		},
	)

	dnsMap["api.cloudflareclient.com"] = ""
	for _, url := range hopt.ConnectionTestUrls { //To avoid dns bug when using urltest
		if host, err := getHostnameIfNotIP(url); err == nil {
			dnsMap[host] = ""
		}
	}
	// for _, d := range ipinfo.GetAllIPCheckerDomainsDomains() {
	// 	dnsMap[d] = ""
	// }
	domains := []string{}
	for domain := range dnsMap {
		domains = append(domains, domain)
	}
	// stable order: the same settings must build the same config (hot reload compares them)
	sort.Strings(domains)
	if len(domains) > 0 {
		forceDirectRules = append(forceDirectRules,
			option.DefaultDNSRule{
				RawDefaultDNSRule: option.RawDefaultDNSRule{
					Domain: domains,
				},
				DNSRuleAction: option.DNSRuleAction{
					Action: C.RuleActionTypeRoute,
					RouteOptions: option.DNSRouteActionOptions{
						Server: DNSMultiDirectTag,
						AbstractDNSRouteActionOptions: option.AbstractDNSRouteActionOptions{
							Strategy:       hopt.DirectDnsDomainStrategy,
							RewriteTTL:     &DEFAULT_DNS_TTL,
							BypassIfFailed: false,
						},
					},
				},
			},
		)
		// forceDirectRules = append(forceDirectRules,
		// 	option.DefaultDNSRule{
		// 		RawDefaultDNSRule: option.RawDefaultDNSRule{
		// 			Domain: domains,
		// 		},
		// 		DNSRuleAction: option.DNSRuleAction{
		// 			Action: C.RuleActionTypeRoute,
		// 			RouteOptions: option.DNSRouteActionOptions{
		// 				Server:         DNSTricksDirectTag,
		// 				Strategy:       hopt.DirectDnsDomainStrategy,
		// 				BypassIfFailed: false,
		// 			},
		// 		},
		// 	},
		// )
		// forceDirectRules = append(forceDirectRules,
		// 	option.DefaultDNSRule{
		// 		RawDefaultDNSRule: option.RawDefaultDNSRule{
		// 			Domain: domains,
		// 		},
		// 		DNSRuleAction: option.DNSRuleAction{
		// 			Action: C.RuleActionTypeRoute,
		// 			RouteOptions: option.DNSRouteActionOptions{
		// 				Server:         DNSLocalTag,
		// 				Strategy:       hopt.DirectDnsDomainStrategy,
		// 				BypassIfFailed: false,
		// 			},
		// 		},
		// 	},
		// )
	}
	return forceDirectRules, nil

}

// dnsGroupIgnoreRange: answers in this range count as failures, so the group tries the next server
const dnsGroupIgnoreRange = "10.10.34.0/24"

// dnsGroupAddresses lists the group members in order: the selected address, its TCP and TLS variants,
// then a fallback resolver (8.8.8.8, or 1.1.1.1 when the selection already is 8.8.8.8) over UDP, TCP and TLS.
func dnsGroupAddresses(selected string) []string {
	if selected != "local" && selected != "fakeip" {
		selected = getDnsAddress(selected)
	}
	host := ""
	if u, err := url.Parse(selected); err == nil {
		switch u.Scheme {
		case C.DNSTypeUDP, C.DNSTypeTCP, C.DNSTypeTLS, C.DNSTypeHTTPS, C.DNSTypeHTTP3, C.DNSTypeQUIC:
			host = u.Hostname()
		}
	}
	if strings.Contains(host, ":") {
		host = "[" + host + "]"
	}
	fallback := "8.8.8.8"
	if host == fallback {
		fallback = "1.1.1.1"
	}
	candidates := []string{selected}
	if host != "" {
		candidates = append(candidates, "tcp://"+host, "tls://"+host)
	}
	candidates = append(candidates, "udp://"+fallback, "tcp://"+fallback, "tls://"+fallback)
	var addresses []string
	for _, candidate := range candidates {
		if !slices.Contains(addresses, candidate) {
			addresses = append(addresses, candidate)
		}
	}
	return addresses
}

// getDNSGroupOptions builds a sequential DNS group: the already built selected server first,
// then a member per remaining address of dnsGroupAddresses.
func getDNSGroupOptions(tag string, selected option.DNSServerOptions, selectedAddress, domainResolver string, detour func(address string) string) (*option.DNSServerOptions, []option.DNSServerOptions, error) {
	members := []string{selected.Tag}
	var servers []option.DNSServerOptions
	for i, address := range dnsGroupAddresses(selectedAddress)[1:] {
		server, err := getDNSServerOptions(fmt.Sprint(tag, "-", i+1), address, domainResolver, detour(address))
		if err != nil {
			return nil, nil, E.Cause(err, "dns group ", tag, ": ", address)
		}
		members = append(members, server.Tag)
		servers = append(servers, *server)
	}
	return &option.DNSServerOptions{
		Tag:  tag,
		Type: C.DNSTypeGroup,
		Options: &option.GroupDNSServerOptions{
			Servers:      members,
			Mode:         C.DNSGroupModeSequential,
			IgnoreRanges: []badoption.Prefix{badoption.Prefix(netip.MustParsePrefix(dnsGroupIgnoreRange))},
		},
	}, servers, nil
}

func getDNSServerOptions(tag string, dnsurl string, domain_resolver string, detour string) (*option.DNSServerOptions, error) {
	serverURL, _ := url.Parse(dnsurl)
	var serverType string
	if serverURL != nil && serverURL.Scheme != "" {
		serverType = serverURL.Scheme
	} else {
		switch dnsurl {
		case "local", "fakeip":
			serverType = dnsurl
		default:
			serverType = C.DNSTypeUDP
		}
	}
	if res, _ := getHostnameIfNotIP(dnsurl); res == "" {
		domain_resolver = ""
	}
	remoteOptions := option.RemoteDNSServerOptions{
		RawLocalDNSServerOptions: option.RawLocalDNSServerOptions{
			DialerOptions: option.DialerOptions{
				Detour: dialDetour(detour),
				AbstractDialerOptions: option.AbstractDialerOptions{
					DomainResolver: &option.DomainResolveOptions{
						Server:   domain_resolver,
						Strategy: option.DomainStrategy(C.DomainStrategyPreferIPv4),
					},
				},
			},
		},
	}
	o := option.DNSServerOptions{
		Tag: tag,
	}
	switch serverType {
	case C.DNSTypeLocal:
		o.Type = C.DNSTypeLocal
		o.Options = &option.LocalDNSServerOptions{
			RawLocalDNSServerOptions: remoteOptions.RawLocalDNSServerOptions,
			PreferGo:                 true,
		}
	case C.DNSTypeUDP:
		o.Type = C.DNSTypeUDP
		o.Options = &remoteOptions
		var serverAddr M.Socksaddr
		if serverURL == nil || serverURL.Scheme == "" {
			serverAddr = M.ParseSocksaddr(dnsurl)
		} else {
			serverAddr = M.ParseSocksaddr(serverURL.Host)
		}
		if !serverAddr.IsValid() {
			return nil, E.New("invalid server address")
		}
		remoteOptions.Server = serverAddr.AddrString()
		if serverAddr.Port != 0 && serverAddr.Port != 53 {
			remoteOptions.ServerPort = serverAddr.Port
		}
		remoteOptions.ConnectTimeout = badoption.Duration(5 * time.Second)
		remoteOptions.DisableTCPKeepAlive = true
	case C.DNSTypeTCP:
		o.Type = C.DNSTypeTCP
		o.Options = &remoteOptions
		if serverURL == nil {
			return nil, E.New("invalid server address")
		}
		serverAddr := M.ParseSocksaddr(serverURL.Host)
		if !serverAddr.IsValid() {
			return nil, E.New("invalid server address")
		}
		remoteOptions.Server = serverAddr.AddrString()
		if serverAddr.Port != 0 && serverAddr.Port != 53 {
			remoteOptions.ServerPort = serverAddr.Port
		}
	case C.DNSTypeTLS, C.DNSTypeQUIC:
		o.Type = serverType
		if serverURL == nil {
			return nil, E.New("invalid server address")
		}
		serverAddr := M.ParseSocksaddr(serverURL.Host)
		if !serverAddr.IsValid() {
			return nil, E.New("invalid server address")
		}
		remoteOptions.Server = serverAddr.AddrString()
		if serverAddr.Port != 0 && serverAddr.Port != 853 {
			remoteOptions.ServerPort = serverAddr.Port
		}
		o.Options = &option.RemoteTLSDNSServerOptions{
			RemoteDNSServerOptions: remoteOptions,
		}
	case C.DNSTypeHTTPS, C.DNSTypeHTTP3:
		o.Type = serverType
		httpsOptions := option.RemoteHTTPSDNSServerOptions{
			RemoteTLSDNSServerOptions: option.RemoteTLSDNSServerOptions{
				RemoteDNSServerOptions: remoteOptions,
			},
		}
		o.Options = &httpsOptions
		if serverURL == nil {
			return nil, E.New("invalid server address")
		}
		serverAddr := M.ParseSocksaddr(serverURL.Host)
		if !serverAddr.IsValid() {
			return nil, E.New("invalid server address")
		}
		httpsOptions.Server = serverAddr.AddrString()
		if serverAddr.Port != 0 && serverAddr.Port != 443 {
			httpsOptions.ServerPort = serverAddr.Port
		}
		if serverURL.Path != "/dns-query" {
			httpsOptions.Path = serverURL.Path
		}
		httpsOptions.TLS = &option.OutboundTLSOptions{
			Enabled: true,
		}
		if strings.Contains(dnsurl, "#fragment=") {

			httpsOptions.TLS.Fragment = true
			httpsOptions.TLS.RecordFragment = true

			splt := strings.Split(dnsurl, "#fragment=")
			data := splt[len(splt)-1]
			if delay, err := strconv.Atoi(data); err == nil && delay >= 0 {
				httpsOptions.TLS.FragmentFallbackDelay = badoption.Duration(time.Duration(delay) * time.Millisecond)
			} else {
				// httpsOptions.TLS.FragmentFallbackDelay = badoption.Duration(30 * time.Millisecond)
			}

		}
	// case "rcode":
	// 	var rcode int
	// 	if serverURL == nil {
	// 		return nil, E.New("invalid server address")
	// 	}
	// 	switch serverURL.Host {
	// 	case "success":
	// 		rcode = dnscode.RcodeSuccess
	// 	case "format_error":
	// 		rcode = dnscode.RcodeFormatError
	// 	case "server_failure":
	// 		rcode = dnscode.RcodeServerFailure
	// 	case "name_error":
	// 		rcode = dnscode.RcodeNameError
	// 	case "not_implemented":
	// 		rcode = dnscode.RcodeNotImplemented
	// 	case "refused":
	// 		rcode = dnscode.RcodeRefused
	// 	default:
	// 		return nil, E.New("unknown rcode: ", serverURL.Host)
	// 	}
	// 	o.Type = C.DNSTypeLegacyRcode
	// 	o.Options = rcode
	case C.DNSTypeDHCP:
		o.Type = C.DNSTypeDHCP
		dhcpOptions := option.DHCPDNSServerOptions{}
		if serverURL == nil {
			return nil, E.New("invalid server address")
		}
		if serverURL.Host != "" && serverURL.Host != "auto" {
			dhcpOptions.Interface = serverURL.Host
		}
		o.Options = &dhcpOptions
	case C.DNSTypeFakeIP:
		o.Type = C.DNSTypeFakeIP
		fakeipOptions := option.FakeIPDNSServerOptions{}
		// if legacyOptions, loaded := ctx.Value((*option.LegacyDNSFakeIPOptions)(nil)).(*option.LegacyDNSFakeIPOptions); loaded {
		// 	fakeipOptions.Inet4Range = legacyOptions.Inet4Range
		// 	fakeipOptions.Inet6Range = legacyOptions.Inet6Range
		// }
		o.Options = &fakeipOptions
	default:
		return nil, E.New("unsupported DNS server scheme: ", serverType)

	}
	return &o, nil
}

func getStaticDNSServerOptions(tag string, staticIps *map[string][]string) (*option.DNSServerOptions, error) {
	domain_ips := badjson.TypedMap[string, badoption.Listable[netip.Addr]]{}
	for domain, ips := range *staticIps {
		ipsConverted := make([]netip.Addr, 0, len(ips))
		for _, ip := range ips {
			addr, err := netip.ParseAddr(ip)
			if err != nil {
				return nil, err
			}
			ipsConverted = append(ipsConverted, addr)
		}
		domain_ips.Put(domain, ipsConverted)
	}
	o := option.DNSServerOptions{
		Tag:  tag,
		Type: C.DNSTypeHosts,
		Options: &option.HostsDNSServerOptions{
			Predefined: &domain_ips,
		},
	}
	return &o, nil
}
func getMultiDnsServerOptions(tag string, servers []string, parallel bool) (*option.DNSServerOptions, error) {
	o := option.DNSServerOptions{
		Tag:  tag,
		Type: C.DNSTypeMulti,
		Options: &option.MultiDNSServerOptions{
			Servers:  servers,
			Parallel: parallel,
			IgnoreRanges: []badoption.Prefix{
				badoption.Prefix(netip.MustParsePrefix("10.10.34.0/24")),
				badoption.Prefix(netip.MustParsePrefix("001:4188:2:600::/64")),
			},
		},
	}
	return &o, nil
}
