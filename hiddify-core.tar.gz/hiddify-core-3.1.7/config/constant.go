package config

const (
	WarpOverProxy = "warp_over_proxy"
	ProxyOverWarp = "proxy_over_warp"
)
